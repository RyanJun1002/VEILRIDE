# MISTLINE Model Pack

Blender에서 `File > Import > glTF 2.0 (.glb/.gltf)`로 불러오세요.

## 폴더

- `vehicles/`: 플레이 가능한 탈것 7종(내부 모델 포함)
- `interiors/`: 승용차, 메트로 버스, 오토바이 콕핏 분리본
- `world-props/`: NPC 차량, 나무, 바위, 관목, 산, 도로 반사판

## 규격

- 단위: 미터
- 위쪽: +Y
- 차량 전방: -Z
- 각 파일의 루트 피벗: 월드 원점
- 재질과 계층 이름은 Blender 편집을 위해 자동 정리됨

## 참고

원본 게임 모델은 Three.js 코드로 생성되므로 이 GLB 파일들이 Blender 편집용 변환본입니다.
계기판, 번호판, 버스 노선판의 런타임 캔버스 텍스처는 편집팩에서 빈 자리표시자 텍스처로 변환됩니다.
